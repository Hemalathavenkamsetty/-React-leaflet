def generate_odd_series(a):
    if not isinstance(a, int):
        raise TypeError("Input must be an integer.")
    if a <= 0:
        return ""

    count = (a // 2) if (a % 2 == 0) else ((a + 1) // 2)
    series = [(2 * i + 1) for i in range(count)]
    return ",".join(map(str, series))


print(generate_odd_series(6))  
print(generate_odd_series(7))  
print(generate_odd_series(0))   
print(generate_odd_series(10))