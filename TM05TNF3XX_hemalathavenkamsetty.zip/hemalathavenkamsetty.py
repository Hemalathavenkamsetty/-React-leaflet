def count_multiples(numbers):
    counts = {i: 0 for i in range(1, 10)}
    for number in numbers:
        for i in range(1, 10):
            if number % i == 0:
                counts[i] += 1
    return counts


input_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15]
result = count_multiples(input_list)
print(result)