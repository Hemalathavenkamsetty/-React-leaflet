class Calculator:
    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            return "Cannot divide by zero"
        return a / b

    def calculate(self, a, b, operation):
        if operation == 'add':
            return self.add(a, b)
        elif operation == 'subtract':
            return self.subtract(a, b)
        elif operation == 'multiply':
            return self.multiply(a, b)
        elif operation == 'divide':
            return self.divide(a, b)
        else:
            return "Invalid operation"

calculator = Calculator()
print(calculator.calculate(5, 3, 'add'))      
print(calculator.calculate(5, 3, 'subtract'))  
print(calculator.calculate(5, 3, 'multiply'))  
print(calculator.calculate(5, 0, 'divide'))