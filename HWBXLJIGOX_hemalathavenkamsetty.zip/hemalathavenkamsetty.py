def generate_odd_series(a):
    if not isinstance(a, int) or a <= 0:
        raise ValueError("Input must be a positive integer.")

    odd_numbers = []
    current_odd = 1
    for _ in range(a):
        odd_numbers.append(str(current_odd))
        current_odd += 2
    return ",".join(odd_numbers)


input_value = 5
result = generate_odd_series(input_value)
print(result)  
input_value = 10
result = generate_odd_series(input_value)
print(result)
input_value = 1
result = generate_odd_series(input_value)
print(result) 

try:
    result = generate_odd_series(-3)
except ValueError as e:
    print(e)